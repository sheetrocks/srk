from setuptools import setup
 
setup(
     name='sheetrocks',
     version='0.1'
)        